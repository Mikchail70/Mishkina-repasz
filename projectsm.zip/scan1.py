import os          
import argparse    
import requests  
import json       

def do_ping_sweep(ip, num_of_host):
    ip_parts = ip.split('.')  
    if len(ip_parts) != 4:  
        print("Некорректный IP-адрес")
        return
    network_ip = ip_parts[0] + '.' + ip_parts[1] + '.' + ip_parts[2] + '.'  
    scanned_ip = network_ip + str(int(ip_parts[3]) + num_of_host)  
    response = os.popen(f'ping -c 2 {scanned_ip}')  
    res = response.readlines()  
    if len(res) > 2:  
        print(f"[#] Результаты сканирования: {scanned_ip} [#]\n{res[2]}", end='\n')
    else:
        print(f"[#] Нет ответа от: {scanned_ip} [#]")

def sent_http_request(target, method, headers=None, payload=None):
    if not target or not method:  
        print("Необходимо указать URL и метод")
        return
    headers_dict = dict()  
    if headers:
        for header in headers:
                header_parts = header.split(':')
                if len(header_parts) < 2: 
                    print(f"Некорректный заголовок: {header}")
                    continue
                header_name = header_parts[0]
                header_value = ':'.join(header_parts[1:])
                headers_dict[header_name] = header_value
    if method.upper() == "GET": 
        response = requests.get(target, headers=headers_dict)
    elif method.upper() == "POST":  
        response = requests.post(target, headers=headers_dict, data=payload)
    else:
        print(f"Некорректный метод: {method}")
        return
    print(
        f"[#] Response status code: {response.status_code}\n"
        f"[#] Response headers: {json.dumps(dict(response.headers), indent=4, sort_keys=True)}\n"
        f"[#] Response content:\n {response.text}"
        )

parser = argparse.ArgumentParser(description='Сканер сети или отправка HTTP-запроса')
parser.add_argument('task', choices=['scan', 'sendhttp'], help='Сканирование сети или отправка HTTP-запроса')
parser.add_argument('-i', '--ip', type=str, help='IP address')
parser.add_argument('-n', '--num_of_hosts', type=int, help='Количество хостов')
parser.add_argument('-t', '--target', type=str, help='URL')
parser.add_argument('-m', '--method', type=str, help='Method')
parser.add_argument('-hd', '--headers', type=str, nargs='*', help='Headers')
args = parser.parse_args()

if args.task == 'scan':
    if not args.ip or args.num_of_hosts is None:  
        print("Для сканирования необходимо указать IP-адрес и количество хостов")
    else:
        for host_num in range(args.num_of_hosts):
            do_ping_sweep(args.ip, host_num)
elif args.task == 'sendhttp':
    sent_http_request(args.target, args.method, args.headers)
